<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "fitness";
$con = new mysqli($host, $username, $password, $db);

session_start();
